[![Rust Build and Test](https://github.com/QueenOfSquiggles/Squiggles-Core/actions/workflows/rust.yml/badge.svg?branch=main)](https://github.com/QueenOfSquiggles/Squiggles-Core/actions/workflows/rust.yml)

# Squiggles-Core
A rust port of SC4X
